import java.util.ArrayList;

public class Garage {
    private String navn = "Hidesh's Garage";

    public String getNavn() {
        return navn;
    }

    public void setNavn(String navn) {
        this.navn = navn;
    }

    ArrayList<Bil> bilpark = new ArrayList<Bil>();
    public void addCar(Bil bil){
        bilpark.add(bil);
    }

    public double beregnGrønAfgiftForBilpark(){
        double samletAfgift = 0;
        for(Bil bil:bilpark){
            samletAfgift += bil.beregnGrønEjerafgift();
        }
        return samletAfgift;
    }

    @Override
    public String toString() {
        return "Garage " + getNavn();
    }
}

