public class BenzinBil extends Bil {
    private float kmPrL;
    private int oktanTal;

    public float getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(float kmPrL) {
        this.kmPrL = kmPrL;
    }

    public int getOktanTal() {
        return oktanTal;
    }

    public void setOktanTal(int oktanTal) {
        this.oktanTal = oktanTal;
    }

    public BenzinBil(String regNr, String mærke, String model, int årgang, int antalDøre, int oktanTal, int kmPrL) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.oktanTal = oktanTal;
        this.kmPrL = kmPrL;
    }

    @Override
        public String toString() {
        String beskrivelse = ("\n\nBenzinbil\nRegistreringsnummer: "+getRegNr()+"\nMærke: "+getMærke()+"\nModel: "+getModel()+"\nÅrgang: "+getÅrgang()+"\nAntal døre: "+getAntalDøre() + "\nOktantal: "+getOktanTal()+"\nkmPrL: " + getKmPrL());
        return beskrivelse;
        }



    protected double beregnGrønEjerafgift() {
        double GrønEjerafgift = 0.0;
        if (kmPrL >= 20 && kmPrL < 50) {
            GrønEjerafgift = 330;
        } else if (kmPrL >= 15 && kmPrL < 20) {
            GrønEjerafgift = 1050;
        } else if (kmPrL >= 10 && kmPrL < 15) {
            GrønEjerafgift = 2340;
        } else if (kmPrL >= 5 && kmPrL < 10) {
            GrønEjerafgift = 5500;
        } else if (kmPrL > 5) {
            GrønEjerafgift = 10470;
        } else {
            System.out.println("fejl");
        }
        return GrønEjerafgift;
    }

}
