abstract public class Bil {
    public int årgang, antalDøre;
    public String model, mærke, regNr;

    public Bil(String regNr, String mærke, String model, int årgang, int antalDøre) {
        this.årgang = årgang;
        this.antalDøre = antalDøre;
        this.model = model;
        this.mærke = mærke;
        this.regNr = regNr;
    }

    protected abstract double beregnGrønEjerafgift();

    public int getÅrgang() {
        return årgang;
    }

    public void setÅrgang(int årgang) {
        this.årgang = årgang;
    }

    public String getRegNr() {
        return regNr;
    }

    public void setRegNr(String regNr) {
        this.regNr = regNr;
    }

    public int getAntalDøre() {
        return antalDøre;
    }

    public void setAntalDøre(int antalDøre) {
        this.antalDøre = antalDøre;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMærke() {
        return mærke;
    }

    public void setMærke(String mærke) {
        this.mærke = mærke;
    }

}
