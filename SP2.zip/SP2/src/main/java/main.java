public class main {

    public static void main(String[] args){
        BenzinBil benzinbil = new BenzinBil("CM73542", "Lamborghini", "Huracan", 2016, 3, 100, 8);
        DieselBil dieselbil = new DieselBil("BV15191", "BMW", "335d", 2015, 5, 17, true);
        ElBil elbil = new ElBil("AY81527","Tesla","Model 3", 2019, 4, 81, 250, 350);


        Garage hidesh = new Garage();
        hidesh.addCar(benzinbil);
        hidesh.addCar(dieselbil);
        hidesh.addCar(elbil);

        System.out.println(hidesh.bilpark);
        System.out.println("\nSamlet Afgift: "+hidesh.beregnGrønAfgiftForBilpark()+"DKK");

    }

}
