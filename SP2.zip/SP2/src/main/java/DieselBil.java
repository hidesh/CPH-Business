public class DieselBil extends Bil {
    private int kmPrL;
    private Boolean partikelFilter;

    public int getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(int kmPrL) {
        this.kmPrL = kmPrL;
    }

    public Boolean getPartikelFilter() {
        return partikelFilter;
    }

    public void setPartikelFilter(Boolean partikelFilter) {
        this.partikelFilter = partikelFilter;
    }

    public DieselBil(String regNr, String mærke, String model, int årgang, int antalDøre, int kmPrL, Boolean partikelFilter) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.kmPrL = kmPrL;
        this.partikelFilter = partikelFilter;
    }

    @Override
    public String toString(){
        String beskrivelse = ("\n\nDieselbil\nRegistreringsnummer: "+getRegNr()+"\nMærke: "+getMærke()+"\nModel: "+getModel()+"\nÅrgang: "+getÅrgang()+"\nAntal døre: "+getAntalDøre() + "\nPartikelfilter: "+getPartikelFilter()+ "\nKM pr. liter: "+getKmPrL());
        return beskrivelse;

    }

    protected double beregnGrønEjerafgift(){
        double GrønEjerAfgift = 0.0;
        if(kmPrL >= 20 && kmPrL < 50){
            GrønEjerAfgift = 330.0+130;
        } else if (kmPrL >= 15 && kmPrL < 20){
            GrønEjerAfgift = 1050.0+1390;
        } else if (kmPrL >= 10 && kmPrL < 15 ){
            GrønEjerAfgift = 2340.0+1850;
        } else if (kmPrL >= 5 && kmPrL < 10){
            GrønEjerAfgift = 5500.0+2770;
        }  else if (kmPrL < 5){
            GrønEjerAfgift = 10470.0+15260;
        }else{
            System.out.println("fejl");
        }
        if(!partikelFilter){
            GrønEjerAfgift += 1000;
        }
        return GrønEjerAfgift;

    }

}
