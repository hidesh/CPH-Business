public class ElBil extends Bil {
    private int whPrKm;
    private int maxKm;
    private int batteriKapacitetkWh;


    public int getWhPrKm() {
        return whPrKm;
    }

    public void setWhPrKm(int whPrKm) {
        this.whPrKm = whPrKm;
    }

    public int getMaxKm() {
        return maxKm;
    }

    public void setMaxKm(int maxKm) {
        this.maxKm = maxKm;
    }

    public int getBatteriKapacitetkWh() {
        return batteriKapacitetkWh;
    }

    public void setBatteriKapacitetkWh(int batteriKapacitetkWh) {
        this.batteriKapacitetkWh = batteriKapacitetkWh;
    }

    public ElBil(String regNr, String mærke, String model, int årgang, int antalDøre, int whPrKm, int maxKm, int batteriKapacitetkWh) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.whPrKm = whPrKm;
        this.maxKm = maxKm;
        this.batteriKapacitetkWh = batteriKapacitetkWh;

    }

    @Override
    public String toString(){
        String beskrivelse = ("\n\nElBil\nRegistreringsnummer: "+getRegNr() + "\nMærke: "+getMærke() + "\nModel: "+getModel() + "\nÅrgang: "+getÅrgang() + "\nAntal døre: "+getAntalDøre() + "\nWatt pr. Liter: "+getWhPrKm()+"\nMax Kilometer: " +getMaxKm() + "\nBatteriKapacitet i kWh " +getBatteriKapacitetkWh());
        return beskrivelse;

    }

    protected double beregnGrønEjerafgift(){
        double GrønEjerAfgift = 0.0;
        if(whPrKm >= 456.25 && whPrKm < 182.5){
            GrønEjerAfgift = 330.0;
        } else if (whPrKm >= 608.33 && whPrKm < 456.25){
            GrønEjerAfgift = 1050.0;
        } else if (whPrKm >= 912.5 && whPrKm < 608.33 ){
            GrønEjerAfgift = 2340.0;
        } else if (whPrKm >= 1825 && whPrKm < 912.5){
            GrønEjerAfgift = 5500.0;
        }  else if (whPrKm < 1825){
            GrønEjerAfgift = 10470.0;
        } else{
            System.out.println("error");
        }
        return GrønEjerAfgift;

    }
}

